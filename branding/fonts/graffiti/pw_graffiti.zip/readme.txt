

This font was created by Michel LUN, http://www.peax-webdesign.com 

--------------------------------------------------------------------------

If wou want to contact me : michel.lun@free.fr

--------------------------------------------------------------------------

Follow me on Facebook https://fr-fr.facebook.com/peax.webdesign

and

G+   https://plus.google.com/103595703505477716588

to know about future fonts

--------------------------------------------------------------------------